The following notes were generated across my local OS X install, ubuntu running on travis-ci and win builder. Response to NOTEs across three platforms below.

* This is a new submission.

* Possibly mis-spelled words in DESCRIPTION:  lazyeval
  
  This is the name of the package, not a mispelling.
  
* checking re-building of vignette outputs ... NOTE
  
  The vignettes use rmarkdown, which requires pandocs.  A fix to knitr
  is in progress to eliminate this note.
