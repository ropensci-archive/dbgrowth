.onAttach <- function(...) {
  packageStartupMessage("\n\nNew to solr? See the vignette at vignette('solr_vignette', 'solr')\nAnd vignette('solr_localsetup', 'solr') for tips on local setup of Solr\ncitation(package='solr') for the citation for this package \nUse suppressPackageStartupMessages() to suppress these startup messages in the future\n")
}