library('testthat')
library('solr')

test_check('solr')
