#' PLoS API fields to use for searching/retreiving data.  
#' @name plosfields
#' @docType data
#' @keywords datasets
NULL