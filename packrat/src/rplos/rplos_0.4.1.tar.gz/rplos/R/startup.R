.onAttach <- function(...) {
	packageStartupMessage("\n\n New to rplos? Tutorial at http://ropensci.org/tutorials/rplos_tutorial.html. Use suppressPackageStartupMessages() to suppress these startup messages in the future\n")
} 